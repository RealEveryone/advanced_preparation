from project.car.muscle_car import MuscleCar
from project.car.sports_car import SportsCar

possible_car_types_dict = {'MuscleCar': MuscleCar, 'SportsCar': SportsCar}
from project.car.muscle_car import MuscleCar
from project.car.sports_car import SportsCar

car_types_dict = {'MuscleCar': MuscleCar, 'SportsCar': SportsCar}
